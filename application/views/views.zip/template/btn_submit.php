<hr>
<div class="row">
    <div class="col-sm-8 col-sm-offset-2">
        <button style="background-color: #69bf53; padding: 5px 32px; font-size: 18px;" type="submit" id="submit" name="submit" class="btn-success  btn fa fa-check">&nbsp;&nbsp;SAVE</button>
        <button style="padding: 5px 20px; font-size: 18px;" type="button" id="Cancel" name="Cancel" class="btn btn-danger-alt fa fa-times-circle">&nbsp;&nbsp;CANCEL</button>
    </div>
</div>