<meta charset="utf-8">
<title><?php echo $title; ?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="description" content="Ashan Rathsara">
<meta name="author" content="Ashan Rathsara">


<link href="<?php echo base_url(); ?>assets/fonts/font-awesome/css/font-awesome.min.css" type="text/css" rel="stylesheet">        <!-- Font Awesome -->
<link href="<?php echo base_url(); ?>assets/css/styles.css" type="text/css" rel="stylesheet">                                     <!-- Core CSS with all styles -->

<link href="<?php echo base_url(); ?>assets/plugins/jstree/dist/themes/avenger/style.min.css" type="text/css" rel="stylesheet">    <!-- jsTree -->
<link href="<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.css" type="text/css" rel="stylesheet">                <!-- Code Prettifier -->
<link href="<?php echo base_url(); ?>assets/plugins/iCheck/skins/minimal/blue.css" type="text/css" rel="stylesheet">              <!-- iCheck -->

<!-- The following CSS are included as plugins and can be removed if unused-->

<link href="<?php echo base_url(); ?>assets/plugins/form-daterangepicker/daterangepicker-bs3.css" type="text/css" rel="stylesheet"> 	<!-- DateRangePicker -->
<link href="<?php echo base_url(); ?>assets/plugins/fullcalendar/fullcalendar.css" type="text/css" rel="stylesheet"> 					<!-- FullCalendar -->
<link href="<?php echo base_url(); ?>assets/plugins/charts-chartistjs/chartist.min.css" type="text/css" rel="stylesheet"> 	


<!--<link href="<?php echo base_url(); ?>assets/plugins/form-daterangepicker/daterangepicker-bs3.css" type="text/css" rel="stylesheet">     DateRangePicker 
<link href="<?php echo base_url(); ?>assets/plugins/iCheck/skins/minimal/blue.css" type="text/css" rel="stylesheet">                    Custom Checkboxes / iCheck 
<link href="<?php echo base_url(); ?>assets/plugins/clockface/css/clockface.css" type="text/css" rel="stylesheet">     -->


<!--Sweet Alert-->
<link href="<?php echo base_url(); ?>assets/plugins/sweet_alert/sweetalert.css" type="text/css" rel="stylesheet"> <!-- Clockface -->

<link href="<?php echo base_url(); ?>assets/css/custom_css.css" type="text/css" rel="stylesheet">    

<link href="<?php echo base_url(); ?>assets/plugins/datepicker/css/datepicker.css" type="text/css" rel="stylesheet"> <!-- Datepicker -->
<link href="<?php echo base_url(); ?>assets/plugins/jquery-ui/jquery-ui.css" rel="stylesheet" type="text/css"/>