<script src="<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js"></script> 							 <!-- Load jQuery -->
<script src="<?php echo base_url(); ?>assets/js/jqueryui-1.9.2.min.js"></script> 							 <!-- Load jQueryUI -->
<script src="<?php echo base_url(); ?>assets/plugins/jquery-ui/jquery-ui.js" type="text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<script src="<?php echo base_url(); ?>assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="<?php echo base_url(); ?>assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="<?php echo base_url(); ?>assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->
<script src="<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="<?php echo base_url(); ?>assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script src="<?php echo base_url(); ?>assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script src="<?php echo base_url(); ?>assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->
<script src="<?php echo base_url(); ?>assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script src="<?php echo base_url(); ?>assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->
<script src="<?php echo base_url(); ?>assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->
<script src="<?php echo base_url(); ?>assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script src="<?php echo base_url(); ?>assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="<?php echo base_url(); ?>assets/js/application.js"></script>
<script src="<?php echo base_url(); ?>assets/demo/demo.js"></script>
<!--<script src="<?php echo base_url(); ?>assets/demo/demo-switcher.js"></script>-->
<!-- End loading site level scripts -->

<!-- Load page level scripts-->
<script src="<?php echo base_url(); ?>assets/plugins/fullcalendar/fullcalendar.min.js"></script>   				<!-- FullCalendar -->
<script src="<?php echo base_url(); ?>assets/plugins/wijets/wijets.js"></script>     								<!-- Wijet -->
<script src="<?php echo base_url(); ?>assets/plugins/charts-chartistjs/chartist.min.js"></script>               	<!-- Chartist -->
<script src="<?php echo base_url(); ?>assets/plugins/charts-chartistjs/chartist-plugin-tooltip.js"></script>    	<!-- Chartist -->
<script src="<?php echo base_url(); ?>assets/plugins/form-daterangepicker/moment.min.js"></script>              	<!-- Moment.js for Date Range Picker -->
<script src="<?php echo base_url(); ?>assets/plugins/form-daterangepicker/daterangepicker.js"></script>     				<!-- Date Range Picker -->
<script src="<?php echo base_url(); ?>assets/demo/demo-index.js"></script> 

<!--Data Table JS-->
<script src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/demo/demo-datatables.js"></script>
<!--End Data Table JS-->

<script src="<?php echo base_url(); ?>system_js/utility.js"></script>

<!--Sweet Alert Js-->
<script src="<?php echo base_url(); ?>assets/plugins/sweet_alert/sweetalert.min.js"></script>

<!--Jquary Validation-->
<script src="<?php echo base_url(); ?>assets/plugins/validation/jquery.validate.js"></script>

<!--Bootstrap Datepicker-->
<!--http://www.eyecon.ro/bootstrap-datepicker/-->
<script src="<?php echo base_url(); ?>assets/plugins/datepicker/js/bootstrap-datepicker.js"></script>
